import test from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {mkdtemp,rm,readFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {pbkdf2Sync} from 'node:crypto';
import {defaultDatabasePath} from '../server/runtime-config.mjs';
const root=dirname(dirname(fileURLToPath(import.meta.url)));
test('managed-release data lives outside the directory replaced by a deployment',()=>{
 assert.equal(defaultDatabasePath('/home/user/domains/board.example/hbuilds/versions/release-one/nodejs'),'/home/user/domains/board.example/.buildboard-data/buildboard.sqlite');
 assert.equal(defaultDatabasePath('/home/user/domains/board.example/hbuilds/versions/release-two/nodejs'),'/home/user/domains/board.example/.buildboard-data/buildboard.sqlite');
 assert.equal(defaultDatabasePath('/opt/buildboard'),'/opt/buildboard/storage/buildboard.sqlite');
});
test('root app.js starts the server behind an HTTPS proxy that rewrites Host',async()=>{
 const pkg=JSON.parse(await readFile(join(root,'package.json'),'utf8'));
 assert.equal(pkg.main,'app.js');assert.equal(pkg.scripts.start,'node app.js');
 const dir=await mkdtemp(join(tmpdir(),'buildboard-proxy-')),salt='00112233445566778899aabbccddeeff',publicOrigin='https://board.example';
 const child=spawn(process.execPath,['app.js'],{cwd:root,env:{...process.env,APP_USERNAME:'test-owner',APP_PASSWORD_HASH:`pbkdf2-sha256:100000:${salt}:${pbkdf2Sync('test-only-password',Buffer.from(salt,'hex'),100000,32,'sha256').toString('hex')}`,PUBLIC_URL:publicOrigin,HOST:'127.0.0.1',PORT:'0',DATABASE_PATH:join(dir,'board.sqlite')},stdio:['ignore','pipe','pipe']});
 try{
  const internal=await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(new Error('Server startup timed out')),10000);child.stdout.on('data',chunk=>{const m=chunk.toString().match(/http:\/\/127\.0\.0\.1:\d+/);if(m){clearTimeout(timer);resolve(m[0]);}});child.once('exit',code=>{clearTimeout(timer);reject(new Error('Server exited: '+code));});});
  const page=await fetch(internal+'/login');assert.equal(page.status,200);
  const login=await fetch(internal+'/auth/login',{method:'POST',redirect:'manual',headers:{Origin:publicOrigin},body:new URLSearchParams({username:'test-owner',password:'test-only-password'})});
  assert.equal(login.status,303);assert.match(login.headers.get('set-cookie'),/Secure/);
  const cookie=login.headers.get('set-cookie').split(';')[0];
  const board=await fetch(internal+'/api/state',{headers:{Cookie:cookie}});assert.equal(board.status,200);assert.equal((await board.json()).state.tasks.length,144);
  const wrong=await fetch(internal+'/auth/login',{method:'POST',redirect:'manual',headers:{Origin:'https://attacker.example'},body:'username=test-owner&password=test-only-password'});assert.equal(wrong.status,403);
 }finally{await new Promise(resolve=>{child.once('exit',resolve);child.kill('SIGTERM');});await rm(dir,{recursive:true,force:true});}
});
