import './embed-assets.mjs';
import {cp,mkdir,rm} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {dirname,join} from 'node:path';
const root=dirname(dirname(fileURLToPath(import.meta.url))),output=join(root,'dist');
await rm(output,{recursive:true,force:true});await mkdir(output,{recursive:true});
for(const name of ['app.js','vps-server.mjs','package.json','package-lock.json','server','data','drizzle'])await cp(join(root,name),join(output,name),{recursive:true});
await mkdir(join(output,'client'),{recursive:true});await cp(join(root,'client/core.mjs'),join(output,'client/core.mjs'));
// Runtime values may instead come from hPanel's environment-variable import.
try{await cp(join(root,'.env'),join(output,'.env'));}catch(error){if(error.code!=='ENOENT')throw error;}
console.log('Hostinger runtime ready: dist/app.js and all backend dependencies.');
