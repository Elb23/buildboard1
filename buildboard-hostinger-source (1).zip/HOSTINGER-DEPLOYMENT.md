# Hostinger Node.js deployment

This package runs as a Node.js backend. Its root `app.js` is the server entry.
The browser UI is `client/board-ui.js`; it is served by the authenticated backend.

Upload the complete ZIP using **Upload your website files**, then review the
settings before deploying:

| Setting | Value |
| --- | --- |
| Framework | Other |
| Node.js | 24.x |
| Project/root directory | `.` (the ZIP root) |
| Build command | `npm run build` |
| Output directory | `dist` |
| Entry file | `app.js` |
| Start command, if shown | `npm start` |
| Package manager | npm |

The build copies the complete backend and its runtime files into `dist`.
Selecting `client` as the root or output directory would launch browser code
without the backend. Use the dedicated Hostinger ZIP for these settings.

## Hostinger-specific environment

The Hostinger ZIP is configured for the temporary domain supplied in your error:

```dotenv
HOST=0.0.0.0
PORT=3000
PUBLIC_URL=https://lightseagreen-worm-305811.hostingersite.com
COOKIE_SECURE=1
```

Its private `.env` also includes your configured login and salted password hash.
If hPanel does not load `.env` automatically, use its environment-variable import
to import this file. Do not expose the file through static hosting.
When your site's domain changes, update `PUBLIC_URL` to its exact HTTPS origin.
Existing hPanel environment variables take precedence over the bundled `.env`.

When the runtime is under `hbuilds/versions`, the database defaults to a private
`.buildboard-data` directory under the domain directory, outside the release
folder. `DATABASE_PATH` can override this if your account provides a different
persistent writable directory. Keep database backups or use the UI's export.

The generic VPS ZIP keeps its loopback binding; for manual VPS deployment follow
`VPS-DEPLOYMENT.md` instead.
