// Server entry for Node.js hosting. Browser code lives in client/board-ui.js.
import "./vps-server.mjs";
