# Buildboard · Hostinger Node.js edition

Upload this entire ZIP and follow **HOSTINGER-DEPLOYMENT.md**.

Settings: Other; Node.js 24.x; project root `.`; build `npm run build`; output `dist`; server entry `app.js`; start `npm start`.

The root app.js launches the backend. Browser code lives in client/board-ui.js and is served only after authentication. Your private .env is configured for your supplied Hostinger domain and login, using a salted password hash.

The build creates a complete Node runtime in dist. All 144 sessions, notes, weekly reviews, authentication and both plan PDFs are included.

Run `npm ci`, `npm run build`, and `npm test` to verify the source. Keep the ZIP and .env private.
