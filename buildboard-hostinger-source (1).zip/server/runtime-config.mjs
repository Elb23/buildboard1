import {join,sep} from 'node:path';
export function defaultDatabasePath(root){
  // Hostinger creates a new runtime directory for each hbuilds release.
  // Keep the private database outside those replaceable release directories.
  const marker=`${sep}hbuilds${sep}versions${sep}`;
  const index=root.indexOf(marker);
  return index>0?join(root.slice(0,index),'.buildboard-data','buildboard.sqlite'):join(root,'storage','buildboard.sqlite');
}
